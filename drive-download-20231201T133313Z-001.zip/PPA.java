
class PPA
{
    public static void main(String Arg[])
    {
        System.out.println("Jay Ganesh...");
    }
}

// javac PPA.java       ->  PPA.class
// java PPA             -> Interpretor  -> JVM
// java PPA.java