final class Demo
{
    public int A;
    public int B;
}

class Hello extends Demo
{}

class Final2
{
    public static void main(String arg[])
    {

    }
}