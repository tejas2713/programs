int No = 11;

struct Demo
{
    int i;
    int j;
};
