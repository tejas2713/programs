



class Demo
{
    public static void main (String arg[])
    {
        System.out.println("Jay Ganesh...");
    }
}


















// Compile the code
// javac Demo.java

// Execute the code
// java Demo
// OR
// java Demo.java