#include<stdio.h>

int main()
{
    char Arr[] = {'H','e','l','l','o','\0'};

    char Brr[] = "Hello";

    return 0;
}