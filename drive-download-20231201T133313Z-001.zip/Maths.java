package Marvellous;

public class Maths
{
    public int Addition(int A, int B)
    {
        return A+B;
    }
}

// javac -d . Maths.java
// -d : Directory (Folder)
// . : Current Dictory